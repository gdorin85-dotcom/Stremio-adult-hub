# Stremio Adult Hub 18+

A Stremio catalog addon that aggregates metadata and direct video links from public feeds you own or are authorized to use.

## Requirements

- Node.js 18 or newer (Node 20 recommended)
- A Stremio-compatible public JSON feed from each content provider
- Permission to display the metadata and link to/play the media

## Run locally

```bash
npm install
npm start
```

Open `http://localhost:7000/manifest.json` to verify the manifest. In Stremio, use **Add-on → Community Add-ons** and install:

```text
http://localhost:7000/manifest.json
```

For another device on the same network, replace `localhost` with the computer's LAN IP address.

## Connect provider feeds

Set the `SOURCES` environment variable to a JSON array. Each source must expose a public JSON endpoint:

```json
[
  {
    "id": "provider-a",
    "name": "Provider A",
    "url": "https://provider.example/public-feed.json",
    "enabled": true
  },
  {
    "id": "provider-b",
    "name": "Provider B",
    "url": "https://another.example/catalog.json",
    "enabled": true
  }
]
```

Each feed should return either an array of entries or an object with an `items` array:

```json
{
  "items": [
    {
      "id": "unique-provider-item-id",
      "title": "Video title",
      "description": "Description",
      "poster": "https://provider.example/poster.jpg",
      "background": "https://provider.example/background.jpg",
      "year": 2026,
      "genres": ["Category A", "Category B"],
      "runtime": "00:12:30",
      "streams": [
        {
          "title": "HD",
          "url": "https://provider.example/video.mp4"
        }
      ]
    }
  ]
}
```

`poster`, `background`, and stream `url` must be HTTP(S) URLs. Stream links must be direct playable URLs supplied by the provider and authorized for this use. The addon does not scrape pages, bypass logins, defeat DRM, evade geographic restrictions, or extract hidden/private media URLs.

## Deploy to a cloud host

This project includes a Dockerfile and can be deployed to a service that supports Docker containers.

1. Upload this folder to your Git repository.
2. Create a new Docker web service on your hosting provider.
3. Set the start command to `npm start` if the provider does not use the Dockerfile automatically.
4. Set environment variables `PORT` (usually supplied by the host), `HOST=0.0.0.0`, and `SOURCES`.
5. Enable HTTPS on the hosting provider.
6. Confirm `https://YOUR-HOST/manifest.json` loads.
7. Install `https://YOUR-HOST/manifest.json` in Stremio.

Do not expose provider API keys in feed URLs or source code. If a provider requires authentication, build a provider-specific server adapter that stores credentials as server-side secrets and complies with its terms.

## Important notes

- This is a working addon scaffold with a sample entry, not a preloaded directory of adult sites.
- You must supply feed endpoints and authorized playable URLs. Many adult sites do not provide public feeds or permit third-party playback.
- An addon manifest flag is not a reliable parental lock. Keep the addon away from child profiles/devices and use the parental controls provided by your devices and services.
- Do not use this project to distribute illegal content or content involving minors, non-consensual material, or content uploaded without the rights holder's permission.

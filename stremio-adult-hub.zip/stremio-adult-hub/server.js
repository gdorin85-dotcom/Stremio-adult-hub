const { addonBuilder, serveHTTP } = require("stremio-addon-sdk");
const fs = require("node:fs/promises");
const path = require("node:path");

const PORT = Number(process.env.PORT || 7000);
const HOST = process.env.HOST || "0.0.0.0";
const CACHE_TTL_MS = Number(process.env.CACHE_TTL_MS || 5 * 60 * 1000);
const SAMPLE_FILE = path.join(__dirname, "data", "sample-feed.json");

const manifest = {
  id: "community.adulthub.catalog",
  version: "1.0.0",
  name: "Adult Hub 18+",
  description: "Catalog aggregator for authorized adult-content feeds. Adults only (18+).",
  logo: "https://www.stremio.com/website/logo.png",
  resources: ["catalog", "meta", "stream"],
  types: ["movie"],
  idPrefixes: ["adulthub:"],
  catalogs: [{
    type: "movie",
    id: "adulthub",
    name: "Adult Hub 18+",
    extra: [
      { name: "search", isRequired: false },
      { name: "genre", isRequired: false }
    ]
  }],
  behaviorHints: { adult: true }
};

const builder = new addonBuilder(manifest);
let cache = { expiresAt: 0, items: [] };

function configuredSources() {
  if (!process.env.SOURCES) return [];
  try {
    const parsed = JSON.parse(process.env.SOURCES);
    if (!Array.isArray(parsed)) throw new Error("SOURCES must be a JSON array");
    return parsed.filter(s => s && typeof s.url === "string" && s.enabled !== false);
  } catch (err) {
    console.error("Invalid SOURCES configuration:", err.message);
    return [];
  }
}

async function readSampleFeed() {
  const raw = await fs.readFile(SAMPLE_FILE, "utf8");
  return JSON.parse(raw);
}

async function fetchJson(url) {
  const response = await fetch(url, {
    headers: { "Accept": "application/json", "User-Agent": "Stremio-Adult-Hub/1.0" },
    signal: AbortSignal.timeout(12000)
  });
  if (!response.ok) throw new Error(`Feed returned HTTP ${response.status}`);
  return response.json();
}

async function loadItems(force = false) {
  if (!force && Date.now() < cache.expiresAt) return cache.items;

  const sources = configuredSources();
  const collected = [];

  if (sources.length === 0) {
    const sample = await readSampleFeed();
    normalizeFeed(sample, "sample", collected);
  } else {
    const results = await Promise.allSettled(
      sources.map(async (source, index) => {
        const feed = await fetchJson(source.url);
        normalizeFeed(feed, source.id || `source${index + 1}`, collected);
      })
    );
    results.forEach((result, i) => {
      if (result.status === "rejected") {
        console.error(`Source ${sources[i].name || sources[i].url} failed:`, result.reason.message);
      }
    });
  }

  cache = { items: collected, expiresAt: Date.now() + CACHE_TTL_MS };
  return cache.items;
}

function normalizeFeed(feed, sourceId, output) {
  const items = Array.isArray(feed) ? feed : feed.items;
  if (!Array.isArray(items)) return;

  for (const item of items) {
    if (!item || !item.id || !item.title) continue;
    const id = `adulthub:${sourceId}:${String(item.id)}`;
    const genres = Array.isArray(item.genres) ? item.genres.filter(g => typeof g === "string") : [];
    output.push({
      id,
      type: "movie",
      name: String(item.title),
      description: typeof item.description === "string" ? item.description : "",
      poster: safeHttpUrl(item.poster),
      background: safeHttpUrl(item.background),
      releaseInfo: item.year ? String(item.year) : undefined,
      genres,
      runtime: typeof item.runtime === "string" ? item.runtime : undefined,
      sourceId,
      sourceItemId: String(item.id),
      streams: Array.isArray(item.streams) ? item.streams : []
    });
  }
}

function safeHttpUrl(value) {
  if (typeof value !== "string") return undefined;
  try {
    const parsed = new URL(value);
    return ["http:", "https:"].includes(parsed.protocol) ? value : undefined;
  } catch {
    return undefined;
  }
}

function toMeta(item) {
  const meta = {
    id: item.id,
    type: "movie",
    name: item.name,
    description: item.description,
    genres: item.genres,
    poster: item.poster,
    background: item.background,
    releaseInfo: item.releaseInfo,
    runtime: item.runtime
  };
  Object.keys(meta).forEach(key => meta[key] === undefined && delete meta[key]);
  return meta;
}

builder.defineCatalogHandler(async ({ extra = {} }) => {
  const items = await loadItems();
  const search = String(extra.search || "").trim().toLowerCase();
  const genre = String(extra.genre || "").trim().toLowerCase();

  const filtered = items.filter(item => {
    const matchesSearch = !search ||
      item.name.toLowerCase().includes(search) ||
      item.description.toLowerCase().includes(search);
    const matchesGenre = !genre || item.genres.some(g => g.toLowerCase() === genre);
    return matchesSearch && matchesGenre;
  });

  return { metas: filtered.map(toMeta) };
});

builder.defineMetaHandler(async ({ id }) => {
  const items = await loadItems();
  const item = items.find(entry => entry.id === id);
  return item ? { meta: toMeta(item) } : { meta: null };
});

builder.defineStreamHandler(async ({ id }) => {
  const items = await loadItems();
  const item = items.find(entry => entry.id === id);
  if (!item) return { streams: [] };

  const streams = item.streams
    .filter(stream => stream && safeHttpUrl(stream.url))
    .map(stream => ({
      title: typeof stream.title === "string" ? stream.title : "Authorized source",
      url: safeHttpUrl(stream.url),
      ...(stream.behaviorHints && typeof stream.behaviorHints === "object"
        ? { behaviorHints: stream.behaviorHints }
        : {})
    }));

  return { streams };
});

const addonInterface = builder.getInterface();
serveHTTP(addonInterface, { port: PORT, host: HOST });

console.log(`Adult Hub addon listening on http://${HOST}:${PORT}/manifest.json`);
